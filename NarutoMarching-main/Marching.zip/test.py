import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import RegularPolygon
import csv
import json
import random

def read_csv_to_2d_vector(file_path):
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        data = [row for row in reader]
    return data

file_path = 'map.csv' 
map = read_csv_to_2d_vector(file_path)
map.reverse()
startRow = 9
startCol = 1

#for row in map[:]:
#    print(row)
# Load the JSON file
with open('landInfo.json', 'r') as file:
    map_properties = json.load(file)

initFood=1600

class Hexagon:
    def __init__(self, x, y, Food, Award, Valid, Occupied, Edge, Face, Pattern, Label):
        self.x = x
        self.y = y
        self.Food = Food
        self.Award = Award
        self.Valid = Valid
        self.Occupied = Occupied
        self.Edge = Edge
        self.Face = Face
        self.Pattern = Pattern
        self.Label = Label


def hexagon_grid(rows, cols, hex_size,startRow,startCol):
    # Calculate width and height of the grid
    print(len(map))
    print(len(map[0]))
    width = cols * 1.5 * hex_size
    height = rows * np.sqrt(3) * hex_size
    StartRow = startRow
    StartCol = startCol

    
    marchMap = []

    for row in range(rows):
        hex_row = []
        for col in range(cols):
            x_offset = col * 1.5 * hex_size
            y_offset = row * np.sqrt(3) * hex_size
            if col % 2 == 1:
                y_offset += np.sqrt(3)/2 * hex_size
            
            mapCode=map[row][col]
            properties = map_properties.get(mapCode, map_properties["default"])
            # Set the properties
            name = properties["name"]
            edge = properties["edge"]
            face = properties["face"]
            food = properties["food"]
            award = properties["award"]
            pattern = properties["hatch"]
            label = properties["label"]
            if name=="empty":
                valid = False
            else:
                valid = True      
            # Highlight the start position
            if row == rows-StartRow and col == StartCol-1:
                edge = 'red'
                face = 'yellow'
            hexagon_patch = RegularPolygon((x_offset, y_offset), numVertices=6, radius=hex_size, orientation=np.radians(30), edgecolor=edge, facecolor=face,hatch=pattern)
            #ax.add_patch(hexagon_patch)
            
            # Create a Hexagon object with coordinates and random food and award values
            hex_obj = Hexagon(x=row, y=col, Food=food, Award=award,Valid=valid,Occupied=False, Edge=edge,Face=face, Pattern=pattern, Label=label)
            hex_row.append(hex_obj)
            #ax.text(x_offset, y_offset, f'({rows-row},{col+1})', ha='center', va='center', fontsize=9)
            #ax.text(x_offset, y_offset, label, fontsize=20)

        marchMap.append(hex_row)
    

    return marchMap

def resetMap(marchMap):
    for row in marchMap:
        for hexagon in row:
            hexagon.Occupied = False


        
# Define the game environment
class Calculator:
    def __init__(self, marchMap):
        self.marchMap = marchMap

    def calculate_award(self, player_pos):
        row, col = player_pos
        hexagon = self.marchMap[row][col]
        return hexagon.Award

    def calculate_food(self, current_food):
        return current_food - 1

class Player:
    
    def __init__(self, marchMap, start_pos=(startRow, startCol), food=initFood):
        self.marchMap = marchMap
        self.player_pos = start_pos
        self.food = food
        self.total_award = 0
        self.rows = len(marchMap)
        self.cols = len(marchMap[0])
        self.done = False
        self.path = [start_pos]  # Initialize the path with the start
    def getLandInfo(self, player_pos):
        row, col = player_pos
        #print(f"getLandInfo: player_pos={player_pos}, rows={self.rows}, cols={self.cols}")
        if 0 <= self.rows - row < self.rows and 0 <= col - 1 < self.cols:
            return self.marchMap[self.rows - row][col - 1]
        else:
            raise IndexError("Invalid row or column index")


    def get_state(self):
        return (self.player_pos, self.food, self.total_award)

    def is_valid_move(self, new_pos):
        row, col = new_pos        
        if not(0 < row < self.rows and 0 < col < self.cols):
            return False
        hexagon = self.getLandInfo(new_pos)
        if not(hexagon.Valid):
            return False
        if hexagon.Occupied:
            return False
            
        return self.food >= hexagon.Food

    def get_valid_moves(self):
        valid_moves = []
        Actions = [1, 2, 3, 4, 5, 6, 7]#1-6:move,7:jump
        for direction in Actions:
            row, col = self.player_pos
            if direction == 1:
                new_pos = (row - 1, col)
            elif direction == 2:
                if col % 2:
                    new_pos = (row, col + 1)  # odd col
                else:
                    new_pos = (row - 1, col + 1)  # even col
            elif direction == 3:
                if col % 2:
                    new_pos = (row + 1, col + 1)  # odd col
                else:
                    new_pos = (row, col + 1)  # even col
            elif direction == 4:
                new_pos = (row + 1, col)
            elif direction == 5:
                if col % 2:
                    new_pos = (row + 1, col - 1)  # odd col
                else:
                    new_pos = (row, col - 1)  # even col
            elif direction == 6:
                if col % 2:
                    new_pos = (row, col - 1)  # odd col
                else:
                    new_pos = (row - 1, col - 1)  # even col
            else:
                continue
            
            if self.is_valid_move(new_pos):
                valid_moves.append(direction)
        #print(f"Valid moves from position {self.player_pos}: {valid_moves}")        
        return valid_moves
    
    def move_player(self, direction):
        if self.done:
            return self.get_state(), 0, self.done
        row, col = self.player_pos
        if direction == 1:
            new_pos = (row - 1, col)
        elif direction == 2:
            if col % 2:
                new_pos = (row, col+1) #odd col
            else:
                new_pos = (row-1, col+1) #evel col            
        elif direction == 3:
            if col % 2:
                new_pos = (row+1, col+1) #odd col
            else:
                new_pos = (row, col+1) #evel col            
        elif direction == 4:
            new_pos = (row + 1, col)
        elif direction == 5:
            if col % 2:
                new_pos = (row+1, col-1) #odd col
            else:
                new_pos = (row, col-1) #evel col          
        elif direction == 6:
            if col % 2:
                new_pos = (row, col-1) #odd col
            else:
                new_pos = (row-1, col-1) #evel col     
        else:
            return self.get_state(), 0, self.done

        if self.is_valid_move(new_pos):
            self.player_pos = new_pos
            self.path.append(new_pos)  # Add the new position to the path
            hexagon = self.getLandInfo(new_pos)
            self.food -= hexagon.Food
            self.total_award += hexagon.Award
            hexagon.Occupied=True
            if self.food <= 0:
                self.done = True
            return self.get_state(), hexagon.Award, self.done
        else:
            #print("inValid move")
            return self.get_state(), 0, self.done

    def reset(self,start_pos=(startRow, startCol)):
        self.player_pos = (startRow, startCol)
        self.food = initFood
        self.total_award = 0
        self.done = False
        self.path = [start_pos]
        return self.get_state()
     
def plot_hexagon_grid(marchMap, hex_size, startRow, startCol, path):
    rows = len(marchMap)
    cols = len(marchMap[0])
    width = cols * 1.5 * hex_size
    height = rows * np.sqrt(3) * hex_size

    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_aspect(0.618)

    for row in range(rows):
        for col in range(cols):
            x_offset = col * 1.5 * hex_size
            y_offset = row * np.sqrt(3) * hex_size
            if col % 2 == 1:
                y_offset += np.sqrt(3) / 2 * hex_size
            
            hexagon = marchMap[row][col]
            edge = hexagon.Edge
            face = hexagon.Face
            pattern = hexagon.Pattern
            label = hexagon.Label
            
            # Highlight the start position
            if row == rows - startRow and col == startCol - 1:
                edge = 'red'
                face = 'yellow'

            hexagon_patch = RegularPolygon((x_offset, y_offset), numVertices=6, radius=hex_size, orientation=np.radians(30), edgecolor=edge, facecolor=face, hatch=pattern)
            ax.add_patch(hexagon_patch)
            ax.text(x_offset, y_offset, f'({rows - row},{col + 1})', ha='center', va='center', fontsize=9)
            # ax.text(x_offset, y_offset, label, fontsize=20)
    # Draw the path
    adjusted_path = [(rows - row, col - 1) for row, col in path]
    for i in range(len(adjusted_path) - 1):
        start_pos = adjusted_path[i]
        end_pos = adjusted_path[i + 1]
        start_x = start_pos[1] * 1.5 * hex_size
        start_y = start_pos[0] * np.sqrt(3) * hex_size
        if start_pos[1] % 2 == 1:
            start_y += np.sqrt(3) / 2 * hex_size
        end_x = end_pos[1] * 1.5 * hex_size
        end_y = end_pos[0] * np.sqrt(3) * hex_size
        if end_pos[1] % 2 == 1:
            end_y += np.sqrt(3) / 2 * hex_size
        ax.plot([start_x, end_x], [start_y, end_y], 'k-', lw=2)
    ax.set_xlim(-hex_size, width + hex_size)
    ax.set_ylim(-hex_size, height + hex_size)
    plt.axis('off')
    plt.show()
    
    
class QLearningAgent:
    def __init__(self, actions, alpha=0.1, gamma=0.9, epsilon=0.5):
        self.q_table = {}
        self.actions = actions
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon

    def get_q_value(self, state, action):
        return self.q_table.get((state, action), 0.0)

    def choose_action(self, state, valid_moves):
        if random.uniform(0, 1) < self.epsilon:
            return random.choice(valid_moves)
        else:            
            q_values = [self.get_q_value(state, action) for action in valid_moves]
            max_q = max(q_values)
            return valid_moves[q_values.index(max_q)]

    def learn(self, state, action, reward, next_state):
        old_q = self.get_q_value(state, action)
        next_max_q = max([self.get_q_value(next_state, a) for a in self.actions])
        new_q = old_q + self.alpha * (reward + self.gamma * next_max_q - old_q)
        self.q_table[(state, action)] = new_q
        
# Generate a 60 x 60 hexagon grid with each hexagon having a size of 1
marchMap = hexagon_grid(len(map), len(map[0]), 5,startRow,startCol)

# player1 = Player(marchMap, start_pos=(startRow, startCol), food=800)
# initial_state = player1.get_state()
# print(f"Initial State: {initial_state}")

# Define the actions
actions = [1, 2, 3, 4, 5, 6]

# Create the Q-learning agent
agent = QLearningAgent(actions)
player1 = Player(marchMap, start_pos=(startRow, startCol), food=800)
# Simulate episodes
num_episodes = 100000
BestPath = []
max_reward = float('-inf')
final_food = float('-inf')

for episode in range(num_episodes):
    resetMap(marchMap)
    state = player1.reset()
    total_reward = 0

    while True:
        valid_moves = player1.get_valid_moves()
        if not valid_moves:
            #print("No valid moves available")
            break
        action = agent.choose_action(state, valid_moves)
        #print(f"Predicted Action: {action}")
        next_state, reward, done = player1.move_player(action)
        agent.learn(state, action, reward, next_state)
        state = next_state
        total_reward += reward

        if done:
            break

    print(f"Episode {episode + 1}: Total Reward: {total_reward} Food Left: {player1.food}")
    if total_reward > max_reward:
        final_food = player1.food
        max_reward = total_reward
        BestPath = player1.path
    elif total_reward == max_reward and player1.food > final_food:
        final_food = player1.food
        max_reward = total_reward
        BestPath = player1.path
print(f"The episode with the highest reward has a total reward of {max_reward} with {final_food} food left, and the path is {BestPath}.")



#print(player1.path)

plot_hexagon_grid(marchMap, hex_size=5, startRow=9, startCol=1,path=BestPath)
